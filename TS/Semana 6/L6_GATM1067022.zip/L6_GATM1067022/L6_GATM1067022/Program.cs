﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6_GATM1067022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int mes;
            Console.WriteLine("ejercicio 1");
            Console.WriteLine("Ingrese número de mes");
            mes = int.Parse(Console.ReadLine());

            switch (mes)
            {
                case 1:
                    Console.WriteLine("Mes: Enero");
                    break;
                case 2:
                    Console.WriteLine("Mes: Febrero");
                    break;
                case 3:
                    Console.WriteLine("Mes: Marzo");
                    break;
                case 4:
                    Console.WriteLine("Mes: Abril");
                    break;
                case 5:
                    Console.WriteLine("Mes: Mayo");
                    break;
                case 6:
                    Console.WriteLine("Mes: Junio");
                    break;
                case 7:
                    Console.WriteLine("Mes: Julio");
                    break;
                case 8:
                    Console.WriteLine("Mes: Agosto");
                    break;
                case 9:
                    Console.WriteLine("Mes: Sepriembre");
                    break;
                case 10:
                    Console.WriteLine("Mes: Octubre");
                    break;
                case 11:
                    Console.WriteLine("Mes: Noviembre");
                    break;
                case 12:
                    Console.WriteLine("Mes: Diciembre");
                    break;
                default:
                    Console.WriteLine("Error: El número debe de estar entre 1 y 12");
                    break;


            }
            Console.ReadKey();

            int num1;
            int num2;
            int num3;
            
            Console.WriteLine("ejercicio 2");

            Console.WriteLine("Ingrese el primer número");
            num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el segundo número");
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el tercer número");
            num3 = int.Parse(Console.ReadLine());

            if (num1>num2)
            {
                if (num1>num3)
                {
                    Console.WriteLine("El número"+num1+"es el mayor");
                }
                if (num1 ==num3)
                {
                    Console.WriteLine("El número"+num1+"y"+num3+"son mayores");
                }
                else
                {
                    if (num1==num2)
                    {
                        if (num1>num3)
                        {
                            Console.WriteLine("El número"+num3+"es el mayor");
                        }
                        else
                        {
                            if (num1==num3)
                            {
                                Console.WriteLine("El número"+num2+"es el mayor");
                            }
                        }
                    }
                    else
                    {
                        if (num2>num3)
                        {
                            Console.WriteLine("El número"+num2+"es el mayor");
                        }
                        else
                        {
                            if (num2==num3)
                            {
                                Console.WriteLine("El número"+num2+"y"+num3+"son mayores");
                            }
                            else
                            {
                                Console.WriteLine("El número"+num3+"es el mayor");
                            }
                        }
                    }
                        
                       
                           
                        
                        

                        
                    
                }
            }
            Console.ReadKey();
        }
    }
}
