﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace L8__GATM1067022
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = int.Parse(textBox1.Text);
            int suma = 0;
            for (int i = 1; i <= n; i++)
            {
                suma = suma + i;

            }
            label3.Text = Convert.ToString(suma);



        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            string tabla = "";
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    if (j <= 9)
                    {
                        tabla = tabla + Convert.ToString(i * j)+"\t";
                    }
                    if (j == 10)
                    {
                        tabla = tabla + Convert.ToString(i * j) + "\n";
                    }
                }
                
            }
            label4.Text = Convert.ToString(tabla);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
          
        }
        private void tabPage3_Click(object sender, EventArgs e)
        {
            int numE = int.Parse(textBox2.Text);
            int suma = 0;
            for (int i = 1; i<numE; i++)
            {
                if (numE%i==0)
                {
                    suma=suma+i;
                }

            }


            if (suma==numE)
            {
                label6.Text = "El número es perfecto";
            }
            else
            {
                label6.Text = "El número no es perfecto";
            }



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int I = comboBox1.SelectedIndex;
            switch (I)
            {
                case 0:
                    tabControl1.SelectedIndex=0;
                    break;
                case 1:
                    tabControl1.SelectedIndex=1;
                    break;
                case 2:
                    tabControl1.SelectedIndex=2;
                    break;
            }
        }
    }
}
