﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection.Emit;

namespace T8_GATM1067022
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)

                              
            {
                int n=  int.Parse(textBox1.Text);
                int x = n;
                int res;
                string bin = string.Empty;

                while (n > 0)
                {
                    res = n % 2;
                    n /= 2;
                    bin = res.ToString() + bin;
                }
                label2.Text = x+" es igual a "+bin;
            }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int num = int.Parse(textBox2.Text);
            int y = num;
            string resultado = string.Empty;
            
            switch (num)
            {
                case 10:
                    resultado= "A";
                    break;
                    
                case 11:
                    resultado= "B";
                    break;

                case 12:
                    resultado= "C";
                    break;

                case 13:
                    resultado= "D";
                    break;
                    
                case 14:
                    resultado= "E";
                    break;
                    
                case 15:
                    resultado= "F";
                    break;
                    
            }
            while (num > 0)
            {
                int resto = num % 16;
                num = num / 16;
                resultado = resto.ToString() + resultado;
            }
            if (10<=num && num<=15)
            {
                label4.Text = " es igual a "+resultado;
            }
            else
            {
                label4.Text = y+" es igual a "+resultado;
            }

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {

        }
    }
}

