﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Final_Proramación //Hecho por Gerson Adrián Tobar Marroquín y Oscar Andrés Gómez Morales
{                                                  //1067022                               1098122
    internal class Program
    {
        static int opcion;
        static void menu2()
        {
            int opc = 0;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("Seleccione el el numero de la función que necesita");
                    Console.WriteLine("1. Ventilación ");
                    Console.WriteLine("2. Califacción");
                    Console.WriteLine("3. Iluminación ");
                    opc = int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {

                }
            } while (opc != 1 && opc != 2 && opc != 3);

            switch (opc)
            {
                case 1:
                    Ventilacion();
                    break;
                case 2:
                    Califaccion();
                    break;
                case 3:
                    Iluminacion();
                    break;
            }
        }

        static void Ventilacion()
        {
            Console.Clear();
            Console.WriteLine("Opciones de Ventilación");

            string t = DateTime.Now.ToString("HH:mm tt");
            Console.WriteLine("La hora actual es de "+t);
            int h = int.Parse(t.Substring(0, 2));
            int m = int.Parse(t.Substring(3, 2));
            int[] T1 = new int[2];
            int[] T2 = new int[2];


            Console.WriteLine("Ingrese el intervalo de encendido de la ventilación en horas y minutos sin dos puntos");
            Console.WriteLine("hora: ");
            T1[0]=int.Parse(Console.ReadLine());
            Console.WriteLine("minuto: ");
            T1[1]=int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine("a");
            Console.WriteLine();
            Console.WriteLine("hora: ");
            T2[0]=int.Parse(Console.ReadLine());
            Console.WriteLine("minuto: ");
            T2[1]=int.Parse(Console.ReadLine());

            if (T1[0] >24)
            {
                Console.WriteLine("Hora no valida");
            }
            if (T1[1]>60)
            {
                Console.WriteLine("Minuto no valido");
            }

            if (T2[0] >24)
            {
                Console.WriteLine("Hora no valida");
            }
            if (T2[1]>60)
            {
                Console.WriteLine("Minuto no valido");
            }

            Console.WriteLine("El intervalo es de "+T1[0]+":"+T1[1]+" a "+T2[0]+":"+T2[1]);
            //
            Random humedad = new Random();
            int ha = humedad.Next(0, 100);

            if (h>T1[0])
            {
                if (h<T2[0])
                {
                    //si
                    if (ha<70)
                    {
                        Console.WriteLine("Nivel de humedad en el aire normal "+ha+"% , VENTILACIÓN APAGADA");
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine("Nivel de humedad en el aire alto "+ha+"% VENTILACIÓN ENCENDIDA");
                        Console.WriteLine();
                    }
                }
                if (h==T2[0])
                {
                    if (m<T2[1])
                    {
                        //si
                        if (ha<70)
                        {
                            Console.WriteLine("Nivel de humedad en el aire normal "+ha+"% , VENTILACIÓN APAGADA");
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine("Nivel de humedad en el aire alto "+ha+"% ,VENTILACIÓN ENCENDIDA");
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        //no
                        Console.WriteLine("VENTILACIÓN APAGADA");
                        Console.WriteLine();
                    }
                }
                else
                {
                    //no
                    Console.WriteLine("VENTILACIÓN APAGADA");
                    Console.WriteLine();
                }
            }
            if (h==T2[0])
            {
                if (m>T1[1])
                {
                    if (h<T2[0])
                    {
                        //si
                        if (ha<70)
                        {
                            Console.WriteLine("Nivel de humedad en el aire normal "+ha+"% ,VENTILACIÓN APAGADA");
                            Console.WriteLine();
                        }
                        else
                        {
                            Console.WriteLine("Nivel de humedad en el aire alto "+ha+"% ,VENTILACIÓN ENCENDIDA");
                            Console.WriteLine();
                        }
                    }
                    if (h==T2[0])
                    {
                        if (m<T2[1])
                        {
                            //si
                            if (ha<70)
                            {
                                Console.WriteLine("Nivel de humedad en el aire normal "+ha+"% , VENTILACIÓN APAGADA");
                                Console.WriteLine();
                            }
                            else
                            {
                                Console.WriteLine("Nivel de humedad en el aire alto "+ha+"% ,VENTILACIÓN ENCENDIDA");
                                Console.WriteLine();
                            }
                        }
                        else
                        {
                            //no
                            Console.WriteLine("VENTILACIÓN APAGADA");
                            Console.WriteLine();
                        }
                    }
                }
                else
                {
                    //no
                    Console.WriteLine("VENTILACIÓN APAGADA");
                    Console.WriteLine();
                }
            }
            else
            {
                //no
                Console.WriteLine("VENTILACIÓN APAGADA");
                Console.WriteLine();
            }


            Console.ReadKey();
        

        
        }
        static void Califaccion()
        {
            Console.Clear();
            Console.WriteLine("Opciónes de Califacción");
            Console.WriteLine();

            Random t = new Random();
            float sum = 0;
            float sum2 = 0;
            float sums = 0;

            for (int h = 0; h<5; h++)

            {
                int Ta = t.Next(-20, 55);
                Console.WriteLine("La temperatura ambiente es: "+Ta+ "°C");

                int Tcuarto1 = Ta+2;
                int Tcuarto2 = Ta+3;
                int Tsala = Ta-3;
                int r = 22-Tcuarto1;
                int r2 = 22-Tcuarto2;
                int rs = 22-Tsala;
                int R = Tcuarto1-22;
                int R2 = Tcuarto2-22;
                int Rs = Tsala-22;
                int newTcuarto1;
                int newTcuarto2;
                int newTsala;

                //cuarto1
                if (Tcuarto1==22)
                {
                    Console.WriteLine("Temperatura de Cuarto 1 Optima");
                    Console.WriteLine("Temperatura actual: "+Tcuarto1+"°C");
                    Console.WriteLine();

                    sum=sum+Tcuarto1;
                }

                if (Tcuarto1>18 && Tcuarto1<22)
                {
                    Console.WriteLine("Temperatura de cuarto 1 baja");
                    newTcuarto1=Tcuarto1+r;
                    Console.WriteLine("Cambiando temperatura de "+Tcuarto1+ "°C a "+newTcuarto1+"°C");
                    Console.WriteLine();
                    sum=sum+Tcuarto1;
                }

                if (Tcuarto1<18)
                {
                    Console.WriteLine("Temperatura de cuarto 1 PELIGROSAMENTE baja");
                    newTcuarto1=Tcuarto1+r;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tcuarto1+ "°C a "+newTcuarto1+"°C");
                    Console.WriteLine();
                    sum=sum+Tcuarto1;
                }

                if (Tcuarto1<40&& Tcuarto1>22)
                {
                    Console.WriteLine("Temperatura de cuarto 1 alta");
                    newTcuarto1=Tcuarto1-R;
                    Console.WriteLine("Cambiando temperatura de "+Tcuarto1+"°C a "+newTcuarto1+"°C");
                    Console.WriteLine();
                    sum=sum+Tcuarto1;
                }

                if (Tcuarto1>40)
                {
                    Console.WriteLine("Temperatura de cuarto 1 PELIGROSAMENTE alata");
                    newTcuarto1=Tcuarto1-R;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tcuarto1+"°C a "+newTcuarto1+"°C");
                    Console.WriteLine();
                    sum=sum+Tcuarto1;
                }
                //cuarto2
                if (Tcuarto2==22)
                {
                    Console.WriteLine("Temperatura de Cuarto 2 Optima");
                    Console.WriteLine("Temperatura actual: "+Tcuarto2+"°C");
                    Console.WriteLine();
                    sum2=sum2+Tcuarto2;
                }

                if (Tcuarto2>18 && Tcuarto2<22)
                {
                    Console.WriteLine("Temperatura de cuarto 2 baja");
                    newTcuarto2=Tcuarto2+r2;
                    Console.WriteLine("Cambiando temperatura de "+Tcuarto2+ "°C a "+newTcuarto2+"°C");
                    Console.WriteLine();
                    sum2=sum2+Tcuarto2;
                }

                if (Tcuarto2<18)
                {
                    Console.WriteLine("Temperatura de cuarto 2 PELIGROSAMENTE baja");
                    newTcuarto2=Tcuarto2+r2;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tcuarto2+ "°C a "+newTcuarto2+"°C");
                    Console.WriteLine();
                    sum2=sum2+Tcuarto2;
                }

                if (Tcuarto2<40 && Tcuarto2>22)
                {
                    Console.WriteLine("Temperatura de cuarto 2 alta");
                    newTcuarto2=Tcuarto2-R2;
                    Console.WriteLine("Cambiando temperatura de "+Tcuarto2+"°C a "+newTcuarto2+"°C");
                    Console.WriteLine();
                    sum2=sum2+Tcuarto2;
                }

                if (Tcuarto2>40)
                {
                    Console.WriteLine("Temperatura de cuarto 2 PELIGROSAMENTE alata");
                    newTcuarto2=Tcuarto2-R;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tcuarto2+"°C a "+newTcuarto2+"°C");
                    Console.WriteLine();
                    sum2=sum2+Tcuarto2;
                }

                //sala

                if (Tsala==22)
                {
                    Console.WriteLine("Temperatura de la sala Optima");
                    Console.WriteLine("Temperatura actual: "+Tsala+"°C");
                    Console.WriteLine();
                    sums=sums+Tsala;
                }

                if (Tsala>18 && Tsala<22)
                {
                    Console.WriteLine("Temperatura de del la sala baja");
                    newTsala=Tsala+rs;
                    Console.WriteLine("Cambiando temperatura de "+Tsala+ "°C a "+newTsala+"°C");
                    Console.WriteLine();
                    sums=sums+Tsala;
                }

                if (Tsala<18)
                {
                    Console.WriteLine("Temperatura de la sala PELIGROSAMENTE baja");
                    newTsala=Tsala+rs;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tsala + "°C a "+newTsala+"°C");
                    Console.WriteLine();
                    sums=sums+Tsala;
                }

                if (Tsala<40 && Tsala>22)
                {
                    Console.WriteLine("Temperatura de la sala alta");
                    newTsala=Tsala-Rs;
                    Console.WriteLine("Cambiando temperatura de "+Tsala+"°C a "+newTsala+"°C");
                    Console.WriteLine();
                    sums=sums+Tsala;
                }

                if (Tsala>40)
                {
                    Console.WriteLine("Temperatura de la sala PELIGROSAMENTE alata");
                    newTsala=Tsala-Rs;
                    Console.WriteLine("Cambiando rapidamente temperatura de "+Tsala+"°C a "+newTsala+"°C");
                    Console.WriteLine();
                    sums=sums+Tsala;

                }
            }
            float promedioTc1 = sum/5;
            Console.WriteLine("El promedio de temperaturas en el cuarto 1 es de "+promedioTc1+"°C");
            Console.WriteLine();

            float promedioTc2 = sum2/5;
            Console.WriteLine("El promedio de temperaturas en el cuarto 2 es de "+promedioTc2+"°C");
            Console.WriteLine();

            float promedioTs = sums/5;
            Console.WriteLine("El promedio de temperaturas en la sala es de "+promedioTs+"°C");
            Console.WriteLine();


            Console.ReadKey();
        }
        static void Iluminacion()
        {
            Console.Clear();
            Console.WriteLine("Iluminación");
            Random l = new Random();

            int S = l.Next(1, 3);

            if (S==1)
            {
                Console.WriteLine("Luces de Sala encendidas");
                Console.WriteLine();
                int C1 = l.Next(1, 3);
                int C2 = l.Next(1, 3);

                if (C1==1)
                {
                    Console.WriteLine("Luces de cuarto 1 encendidas");
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Luces de cuarto 1 apagadas");
                    Console.WriteLine();
                }

                if (C2==1)
                {
                    Console.WriteLine("Luces de cuarto 2 encendidas");
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Luces de cuarto 2 apagadas");
                    Console.WriteLine();
                }

            }
            else
            {
                Console.WriteLine("Luces de la sala apagadas");
            }


            Console.ReadKey();
        }
        static void menu1()
        {
            opcion = 0;
            do
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("Ingrese el campo que desea observar");
                    Console.WriteLine("1.Ventilación ");
                    Console.WriteLine("2.Califacción ");
                    Console.WriteLine("3.Iluminación ");
                    Console.WriteLine("4.Panel de control ");
                    Console.WriteLine("5.Salir ");                    
                    opcion = int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {

                }
            } while (opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5);
            if (opcion == 4)
            {
                menu2();
            }
            else
            {
                if (opcion == 5)
                {
                    Console.WriteLine("Cerrando Programa");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Sin acceso");
                    Console.ReadKey();
                }
            }
        }
        static void Main(string[] args)
        {
            do
            {
                menu1();
            } while (opcion != 5);
        }
    }
    
        
        
    }

