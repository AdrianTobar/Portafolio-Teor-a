﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_GATM_1067022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float[] seccionA = new float[10];
            Console.WriteLine("Escriba las notas de los estudiantes de la sección A");
            for (int i = 0; i<10; i++)
            {
                Console.WriteLine("Ingrese notas del estudiante "+(i+1)+":");
                seccionA[i]=int.Parse(Console.ReadLine());

            }

            float[] seccionB = new float[10];

            Console.WriteLine("Escriba las notas de los estudiantes de la sección B");
            for (int i = 0; i<10; i++)
            {
                Console.WriteLine("Ingrese notas del estudiante "+(i+1)+":");
                seccionB[i]=int.Parse(Console.ReadLine());

            }
            //porcentajes
            int contadorA = 0;
            int contadorD = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionA[i]>=65)
                {
                    contadorA++;

                }
                else
                {
                    contadorD++;
                }

            }
            float porcentajeA = (contadorA*100)/10;
            float porcentajeD = (contadorD*100)/10;
            Console.WriteLine("El porcentaje de aprobados de la sección A es: "+porcentajeA+"%");
            Console.WriteLine("El porcentaje de desaprobados de la sección A es: "+porcentajeD+"%");

            int contadorbA = 0;
            int contadorbD = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionB[i]>=65)
                {
                    contadorbA++;

                }
                else
                {
                    contadorbD++;
                }

            }
            float porcentajebA = (contadorbA*100)/10;
            float porcentajebD = (contadorbD*100)/10;
            Console.WriteLine("El porcentaje de aprobados de la sección B es: "+porcentajebA+"%");
            Console.WriteLine("El porcentaje de desaprobados de la sección B es: "+porcentajebD+"%");

            float porcentajeAt = ((contadorA+contadorbA)*100)/20;
            float porcentajeDt = ((contadorD +contadorbD)*100)/20;
            Console.WriteLine("El porcentaje general de aprobación es: "+porcentajeAt+"%");
            Console.WriteLine("El porcentaje general de desaprobación es: "+porcentajeDt+"%");

            //promedios

            float sumaA = seccionA.Sum();
            float sumaB = seccionB.Sum();
            float promedioA = sumaA/10;
            float promedioB = sumaB/10;
            float promedioT = (sumaA+sumaB)/20;

            Console.WriteLine("El promedio de la sección A es: "+promedioA);
            Console.WriteLine("El promedio de la sección B es: "+promedioB);
            Console.WriteLine("El promedio general es: "+promedioT);

            //cantidades
            int contadorp1A = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionA[i]>=90 )
                {
                    contadorp1A++;
                }
            }
            int contadorp1B = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionB[i]>=90)
                {
                    contadorp1B++;
                }
            }

            int cantidad90 = contadorp1A+contadorp1B;
            Console.WriteLine("La cantidad de estudiantes con 90 pts son: "+cantidad90);

            int contadorp2A = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionA[i]>=75)
                {
                    contadorp2A++;
                }
            }
            int contadorp2B = 0;
            for (int i = 0; i<10; i++)
            {
                if (seccionB[i]>=75)
                {
                    contadorp2B++;
                }
            }

            int cantidad75 = contadorp2A+contadorp2B;
            Console.WriteLine("La cantidad de estudiantes con 75 pts son: "+cantidad75);

            Console.ReadKey();

        }
    }
}
